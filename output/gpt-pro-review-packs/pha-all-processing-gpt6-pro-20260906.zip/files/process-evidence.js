/* Audited reference data, not a fitted process optimizer. See docs/PROCESS_REVIEW_20260906.md. */
(function (root) {
  'use strict';
  const VERSION = '2026-09-06';
  const GRADES = {
    S1000P: {
      family: 'Semi-crystalline PHA', scope: 'general', revision: '3/2024',
      source: 'https://cjbiomaterials.com/wp-content/uploads/2024/03/CJBMS-TDS-S1000P.pdf',
      drying: { temperature: '80 °C', hours: '5 h' }, melt: [145,175],
      mfr: '<4 g/10 min · 180 °C / 2.16 kg', impact: '>28 J/m · notched (ASTM D256)',
      injection: { barrel1:[120,130], barrel2:[145,175], nozzle:[145,175], screwRPM:[80,150] }
    },
    A1000P: {
      family: 'Amorphous PHA', scope: 'general', revision: '02/2024',
      source: 'https://cjbiomaterials.com/wp-content/uploads/2024/03/CJBMS-TDS-A1000P.pdf',
      drying: { temperature: '<50 °C', hours:'4–6 h', noteKo:'본문은 50 °C 미만, 표는 50 °C × 5 h입니다. 50 °C를 목표값으로 자동 입력하지 않습니다.', noteEn:'Text: strictly below 50 °C; table: 50 °C × 5 h. Do not auto-fill 50 °C as a target.' },
      melt:[135,175], mfr:'<5 g/10 min · 165 °C / 5 kg',
      injection: { barrel2:[130,165], nozzle:[130,165], screwRPM:[80,150] }
    },
    CA1180P: {
      family: 'PLA + amorphous PHA compound', scope:'injection', revision:'03/2023',
      source:'https://cjbiomaterials.com/wp-content/uploads/2024/03/CJBMS-TDS-CA1180P.pdf',
      drying:{temperature:'60 °C',hours:'5 h'}, mfr:'7 g/10 min · 190 °C / 2.16 kg',
      injection:{barrel1:[155,175],barrel2:[170,185],barrel3:[175,185],nozzle:[175,190],mold:[40,40],packTime:[5,25]},
      highMold:[110,120], speedPct:[10,25]
    },
    CB0104A: {
      family:'scPHA + aPHA + CaCO₃ compound', scope:'injection', revision:'June 2026',
      source:'https://cjbiomaterials.com/wp-content/uploads/2025/03/TDS-CB0104A.pdf',
      drying:{temperature:'75 °C',hours:'4 h'}, melt:[165,175], mfr:'10 g/10 min · 180 °C / 2.16 kg',
      injection:{barrel2:[165,175],nozzle:[165,175],mold:[60,70]}
    },
    CB0400A: {
      family:'scPHA + aPHA + mineral compound', scope:'extrusion', revision:'June 2026',
      source:'https://cjbiomaterials.com/wp-content/uploads/2024/11/PHACT%E2%84%A2-CB0400A.pdf',
      drying:{temperature:'75 °C',hours:'4 h'}, melt:[165,175], mfr:'3 g/10 min · 175 °C / 2.16 kg'
    }
  };
  const FIELD_EN = {zone1:'Zone 1 set temperature',zone2:'Zone 2 set temperature',zone3:'Zone 3 set temperature',zone4:'Zone 4 set temperature',zone5:'Zone 5 set temperature',die:'Die set temperature',screwRPM:'Screw speed',meltPressBar:'Melt pressure',coolingRoll:'Cooling roll temperature',lineSpeed:'Line speed',chillTop:'Top chill roll',chillMid:'Middle chill roll',chillBot:'Bottom chill roll',rollRPM:'Roll speed',targetThickness:'Target thickness',barrel1:'Barrel 1 set temperature',barrel2:'Barrel 2 set temperature',barrel3:'Barrel 3 set temperature',nozzle:'Nozzle set temperature',mold:'Mold temperature',injSpeed:'Injection speed',injPressMPa:'Injection pressure (plastic basis)',packPressMPa:'Packing pressure (plastic basis)',packTime:'Packing time',coolTime:'Cooling time',backPressBar:'Back pressure (confirm basis)',hold1P:'Packing stage 1 pressure',hold1T:'Packing stage 1 time',hold2P:'Packing stage 2 pressure',hold2T:'Packing stage 2 time',bur:'Blow-up ratio (BUR)',flh:'Frost-line height',takeup:'Haul-off speed',dieGap:'Die gap',airTemp:'Cooling air temperature',head:'Head set temperature',accHead:'Accumulator head',blowPressBar:'Blowing air pressure',preBlowBar:'Pre-blowing air pressure'};
  function reference(grade, process, mode) {
    const g=GRADES[grade];
    const ranges=process==='injection' && g?.injection ? {...g.injection} : {};
    if(grade==='CA1180P' && process==='injection' && mode==='high_hdt') ranges.mold=g.highMold;
    return {grade,process,version:VERSION,record:g||null,ranges,validated:false};
  }
  function overrideKey(grade,process,mode){return 'grade:'+grade+'__'+process+(grade==='CA1180P'&&process==='injection'?'__'+(mode||'general'):'');}
  function status(value, range) {
    if(value==='' || value==null) return 'empty';
    const v=Number(value);
    if(!Number.isFinite(v)) return 'invalid';
    if(!Array.isArray(range)||!range.every(Number.isFinite)) return 'unknown';
    return v>=range[0]&&v<=range[1] ? 'ok':'warn';
  }
  function positive(values) {return values.every(v=>Number.isFinite(v)&&v>0);}
  function cooling(thickness,alpha,melt,mold,eject) {
    if(!positive([thickness,alpha])||![melt,mold,eject].every(Number.isFinite)||!(melt>eject&&eject>mold)) return {error:'Require positive thickness/alpha and melt > eject > mold.'};
    // First-term centreline solution for a slab of full thickness, constant surface temperature.
    const ratio=(4/Math.PI)*(melt-mold)/(eject-mold);
    return {seconds:thickness**2/(Math.PI**2*alpha)*Math.log(ratio)};
  }
  function blownFilm(output,density,diameter,bur,speed,gap) {
    if(!positive([output,density,diameter,bur,speed]) || (Number.isFinite(gap)&&gap<=0)) return {error:'All supplied inputs must be positive.'};
    const flow=output/density/3600, d=diameter/1000, v=speed/60;
    const thickness=flow/(Math.PI*d*bur*v)*1e6;
    const result={thickness_um:thickness};
    if(Number.isFinite(gap)) {
      const exitVelocity=flow/(Math.PI*d*gap/1000);
      result.ddr=v/exitVelocity;
      // Same-density thin-annulus approximation: g/(BUR*DDR), not g/2.
      result.gap_based_thickness_um=gap/1000/(bur*result.ddr)*1e6;
    }
    return result;
  }
  // 1 bar*cm² = 10 N; 1 metric tonne-force = 9806.65 N.
  const BAR_CM2_PER_TF=980.665;
  function clamp(pressure,area){return positive([pressure,area])?{tf:pressure*area/BAR_CM2_PER_TF}:{error:'Positive cavity pressure and projected area required.'};}
  function cavityPressure(force,area,fraction){return positive([force,area,fraction])&&fraction<=1?{bar:force*BAR_CM2_PER_TF*fraction/area}:{error:'Positive force/area and 0 < utilization ≤ 1 required.'};}
  const api={VERSION,GRADES,FIELD_EN,reference,overrideKey,status,cooling,blownFilm,clamp,cavityPressure};
  root.PHAEvidence=api;
  if(typeof module!=='undefined'&&module.exports) module.exports=api;
})(typeof globalThis!=='undefined'?globalThis:window);
