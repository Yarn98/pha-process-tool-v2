const test=require('node:test');
const assert=require('node:assert/strict');
const core=require('../process-evidence.js');
test('clamping force uses exact SI conversion and its inverse',()=>{
  assert.equal(core.clamp(980.665,1).tf,1);
  assert.equal(core.cavityPressure(1,1,1).bar,980.665);
  assert.ok(core.clamp(-1,200).error);
  assert.ok(core.cavityPressure(200,0,.8).error);
  assert.ok(core.cavityPressure(200,100,1.2).error);
});
test('film estimate conserves mass, uses one wall, and gap cross-check agrees',()=>{
  const r=core.blownFilm(20,950,80,2.5,30,1);
  const massPerHour=r.thickness_um*1e-6 * Math.PI*.08*2.5 * 30*60 * 950;
  assert.ok(Math.abs(massPerHour-20)<1e-10);
  assert.ok(Math.abs(r.gap_based_thickness_um-r.thickness_um)<1e-10);
  assert.equal(core.blownFilm(40,950,80,2.5,30).thickness_um,2*r.thickness_um);
  for(const bad of [0,-1,Infinity,NaN])assert.ok(core.blownFilm(20,950,80,bad,30).error);
  assert.ok(core.blownFilm(20,950,80,2.5,30,0).error);
});
test('cooling respects temperature ordering and the slab diffusion solution',()=>{
  assert.ok(core.cooling(2,.12,170,60,30).error);
  assert.ok(core.cooling(2,.12,170,30,30).error);
  assert.ok(core.cooling(-2,.12,170,30,60).error);
  assert.ok(core.cooling(2,.12,170,0,60).seconds>0);
  const a=core.cooling(2,.12,170,30,60).seconds;
  const b=core.cooling(4,.12,170,30,60).seconds;
  assert.ok(Math.abs(b/a-4)<1e-12);
  // Independent full Fourier series at the predicted centreline time.
  let theta=0;for(let k=0;k<30;k++)theta+=4/Math.PI * (-1)**k/(2*k+1)*Math.exp(-(((2*k+1)*Math.PI)**2)*.12*a/4);
  assert.ok(Math.abs(theta-(60-30)/(170-30))<1e-6);
});
test('manufacturer references do not cross grade, process, or mold mode',()=>{
  assert.deepEqual(core.reference('CA1180P','injection','general').ranges.mold,[40,40]);
  assert.deepEqual(core.reference('CA1180P','injection','high_hdt').ranges.mold,[110,120]);
  assert.deepEqual(core.reference('CB0104A','injection').ranges.mold,[60,70]);
  assert.deepEqual(core.reference('CB0104A','sheet').ranges,{});
  assert.deepEqual(core.reference('CB0400A','injection').ranges,{});
  assert.deepEqual(core.reference('UNKNOWN','injection').ranges,{});
  assert.equal(core.GRADES.A1000P.drying.temperature,'<50 °C');
  assert.match(core.GRADES.A1000P.mfr,/165 °C \/ 5 kg/);
});
test('range status cannot imply physical safety through a unit-free threshold',()=>{
  assert.equal(core.status('0',[0,1]),'ok');
  assert.equal(core.status('1000',[0,1]),'warn');
  assert.equal(core.status('',[0,1]),'empty');
  assert.equal(core.status(100), 'unknown');
  assert.equal(core.status(Infinity,[0,1]),'invalid');
});
