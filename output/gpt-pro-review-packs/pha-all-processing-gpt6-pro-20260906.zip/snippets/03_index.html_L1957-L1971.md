        # Snippet

        - Path: `index.html`
        - Lines: `1957-1971`
        - Reason: Residence, cooling and blown-film UI calculations

        ```html
        1957: function calcResidence(){
1958:   const rho=parseFloat($('kpi_rho').value), vL=parseFloat($('kpi_holdVol').value), rate=parseFloat($('kpi_rate').value);
1959:   const massText=$('kpi_holdMass').value; const m=massText===''?rho*vL/1000:Number(massText);
1960:   if(!Number.isFinite(m)||!Number.isFinite(rate)||m<=0||rate<=0||(massText===''&&!(rho>0&&vL>0))){$('kpi_res_out').textContent=LANG==='ko'?'양의 질량(또는 밀도·용적)과 토출량을 입력하세요.':'Enter positive mass (or density/volume) and throughput.';return;}
1961:   $('kpi_res_out').textContent=(LANG==='ko'?'평균 체류시간 ≈ ':'Mean residence time ≈ ')+(60*m/rate).toFixed(2)+' min';
1962: }
1963: function calcCooling(){
1964:   const result=PHAEvidence.cooling(...['cool_t','cool_alpha','cool_Tm','cool_Tmold','cool_Te'].map(id=>parseFloat($(id).value)));
1965:   $('cool_out').textContent=result.error?(LANG==='ko'?'두께·열확산율 > 0, 용융 > 탈형 > 금형 온도를 확인하세요.':result.error):(LANG==='ko'?'중심부 냉각 근사 ≈ ':'Centreline cooling estimate ≈ ')+result.seconds.toFixed(1)+' s';
1966: }
1967: function calcBlownFilm(){
1968:   const r=PHAEvidence.blownFilm(...['bf_Q','bf_rho','bf_D','bf_BUR','bf_v','bf_gap'].map(id=>parseFloat($(id).value)));
1969:   $('bf_out').textContent=r.error?(LANG==='ko'?'입력한 값은 모두 양수여야 합니다.':r.error):(LANG==='ko'?'단층 두께 ≈ ':'Single-wall thickness ≈ ')+r.thickness_um.toFixed(1)+' µm'+(r.ddr?' / '+(LANG==='ko'?'갭식 교차확인':'Gap cross-check')+' ≈ '+r.gap_based_thickness_um.toFixed(1)+' µm (DDR='+r.ddr.toFixed(2)+')':'');
1970: }
1971: 
        ```
