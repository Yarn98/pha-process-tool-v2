        # Snippet

        - Path: `index.html`
        - Lines: `961-1315`
        - Reason: Korean flash guidance and remedies

        ```html
         961:       <div style="display:grid;grid-template-columns:minmax(180px,1fr) auto auto auto auto;gap:10px;align-items:end;">
 962:         <div>
 963:           <label for="batchIdInput" style="display:block;font-size:11px;letter-spacing:0.14em;text-transform:uppercase;color:var(--muted);margin-bottom:4px;font-family:'JetBrains Mono',monospace;">배치 ID</label>
 964:           <input type="text" id="batchIdInput" placeholder="예: 20260419-A" style="width:100%;padding:8px 10px;border:1px solid #D8D0BE;border-radius:2px;font-family:'JetBrains Mono',monospace;font-size:13px;background:#FAF7EE;" onchange="updateBatchContext({ batch_id: this.value.trim() })">
 965:         </div>
 966:         <div>
 967:           <label style="display:block;font-size:11px;letter-spacing:0.14em;text-transform:uppercase;color:var(--muted);margin-bottom:4px;font-family:'JetBrains Mono',monospace;">조성 JSON</label>
 968:           <input type="file" id="compositionFile" accept=".json,application/json" style="display:none" onchange="loadCompositionFromFile(this.files?.[0])">
 969:           <button type="button" onclick="document.getElementById('compositionFile').click()" style="padding:8px 14px;background:#1A1814;color:#F5F1E8;border:0;border-radius:2px;cursor:pointer;font-family:'JetBrains Mono',monospace;font-size:11px;letter-spacing:0.14em;text-transform:uppercase;">조성 불러오기</button>
 970:         </div>
 971:         <button type="button" id="startBatchSessionBtn" style="padding:8px 14px;background:#2C5D3F;color:#F5F1E8;border:0;border-radius:2px;cursor:pointer;font-family:'JetBrains Mono',monospace;font-size:11px;letter-spacing:0.14em;text-transform:uppercase;">배치 시작</button>
 972:         <button type="button" id="endBatchSessionBtn" hidden style="padding:8px 14px;background:#1A1814;color:#F5F1E8;border:0;border-radius:2px;cursor:pointer;font-family:'JetBrains Mono',monospace;font-size:11px;letter-spacing:0.14em;text-transform:uppercase;">배치 종료</button>
 973:         <button type="button" id="batchContextClear" onclick="clearBatchContext()" style="padding:8px 14px;background:transparent;color:#1A1814;border:1px solid #B8AF99;border-radius:2px;cursor:pointer;font-family:'JetBrains Mono',monospace;font-size:11px;letter-spacing:0.14em;text-transform:uppercase;">초기화</button>
 974:         <div id="batchContextSummary" style="grid-column:1/-1;padding:10px 12px;background:#FAF7EE;border:1px solid #D8D0BE;border-radius:2px;font-family:'JetBrains Mono',monospace;font-size:12px;color:#3A352D;min-height:36px;display:flex;align-items:center;">
 975:           <span style="color:var(--muted);">아직 시작된 배치 세션이 없습니다. 필요하면 조성을 먼저 불러온 뒤 배치를 시작하세요.</span>
 976:         </div>
 977:       </div>
 978:     </div>
 979:   `,
 980:   en: `
 981:     <div id="batchContextBanner" class="calc-recommendation" style="border-left-color:var(--accent);background:var(--paper-2);">
 982:       <h4 style="color:#2C5D3F;">Current batch session</h4>
 983:       <p style="font-size:13px;color:var(--muted);margin-bottom:12px">
 984:         Stage the batch ID and 4HB composition JSON first, then click <strong>Start batch</strong> so new process-log rows stay attached to the same session.
 985:       </p>
 986:       <div style="display:grid;grid-template-columns:minmax(180px,1fr) auto auto auto auto;gap:10px;align-items:end;">
 987:         <div>
 988:           <label for="batchIdInput" style="display:block;font-size:11px;letter-spacing:0.14em;text-transform:uppercase;color:var(--muted);margin-bottom:4px;font-family:'JetBrains Mono',monospace;">Batch ID</label>
 989:           <input type="text" id="batchIdInput" placeholder="e.g. 20260419-A" style="width:100%;padding:8px 10px;border:1px solid #D8D0BE;border-radius:2px;font-family:'JetBrains Mono',monospace;font-size:13px;background:#FAF7EE;" onchange="updateBatchContext({ batch_id: this.value.trim() })">
 990:         </div>
 991:         <div>
 992:           <label style="display:block;font-size:11px;letter-spacing:0.14em;text-transform:uppercase;color:var(--muted);margin-bottom:4px;font-family:'JetBrains Mono',monospace;">Composition JSON</label>
 993:           <input type="file" id="compositionFile" accept=".json,application/json" style="display:none" onchange="loadCompositionFromFile(this.files?.[0])">
 994:           <button type="button" onclick="document.getElementById('compositionFile').click()" style="padding:8px 14px;background:#1A1814;color:#F5F1E8;border:0;border-radius:2px;cursor:pointer;font-family:'JetBrains Mono',monospace;font-size:11px;letter-spacing:0.14em;text-transform:uppercase;">Load composition</button>
 995:         </div>
 996:         <button type="button" id="startBatchSessionBtn" style="padding:8px 14px;background:#2C5D3F;color:#F5F1E8;border:0;border-radius:2px;cursor:pointer;font-family:'JetBrains Mono',monospace;font-size:11px;letter-spacing:0.14em;text-transform:uppercase;">Start batch</button>
 997:         <button type="button" id="endBatchSessionBtn" hidden style="padding:8px 14px;background:#1A1814;color:#F5F1E8;border:0;border-radius:2px;cursor:pointer;font-family:'JetBrains Mono',monospace;font-size:11px;letter-spacing:0.14em;text-transform:uppercase;">End batch</button>
 998:         <button type="button" id="batchContextClear" onclick="clearBatchContext()" style="padding:8px 14px;background:transparent;color:#1A1814;border:1px solid #B8AF99;border-radius:2px;cursor:pointer;font-family:'JetBrains Mono',monospace;font-size:11px;letter-spacing:0.14em;text-transform:uppercase;">Clear</button>
 999:         <div id="batchContextSummary" style="grid-column:1/-1;padding:10px 12px;background:#FAF7EE;border:1px solid #D8D0BE;border-radius:2px;font-family:'JetBrains Mono',monospace;font-size:12px;color:#3A352D;min-height:36px;display:flex;align-items:center;">
1000:           <span style="color:var(--muted);">No batch session has been started yet. Load a composition first if you want to stage it before the run.</span>
1001:         </div>
1002:       </div>
1003:     </div>
1004:   `
1005: };
1006: const FLASH_EVENT_LOGGER_PANEL = {
1007:   ko: `
1008:     <details class="batch-event-sheet" id="batchEventSheet" open>
1009:       <summary class="batch-event-summary">
1010:         <strong>Log event · 이벤트 기록</strong>
1011:         <span>배치 세션 안에 snapshot · addition · anomaly · scrap · note를 남깁니다.</span>
1012:       </summary>
1013:       <div class="batch-event-body">
1014:         <div id="batchEventNotice" class="batch-event-notice">배치를 시작한 뒤 현장 이벤트를 저장하세요.</div>
1015:         <div class="batch-event-kind-row" role="group" aria-label="Event kind">
1016:           <button type="button" class="batch-event-kind-btn" data-event-kind="temp_reading">Snapshot</button>
1017:           <button type="button" class="batch-event-kind-btn" data-event-kind="addition">Addition</button>
1018:           <button type="button" class="batch-event-kind-btn" data-event-kind="anomaly">Anomaly</button>
1019:           <button type="button" class="batch-event-kind-btn" data-event-kind="scrap">Scrap</button>
1020:           <button type="button" class="batch-event-kind-btn" data-event-kind="note">Note</button>
1021:         </div>
1022:         <div class="batch-event-grid">
1023:           <div class="batch-event-block">
1024:             <h4>이벤트 입력</h4>
1025:             <div class="batch-event-field-grid">
1026:               <div class="batch-event-section" id="batchEventAdditionFields" hidden>
1027:                 <div class="batch-event-field-grid two-col">
1028:                   <div class="batch-event-field"><label for="eventAdditionMaterial">추가 재료</label><input id="eventAdditionMaterial" type="text" placeholder="예: talc"></div>
1029:                   <div class="batch-event-field"><label for="eventAdditionQty">추가량 (g)</label><input id="eventAdditionQty" type="number" step="0.1" placeholder="50"></div>
1030:                 </div>
1031:                 <div class="batch-event-field"><label for="eventAdditionReason">추가 이유</label><input id="eventAdditionReason" type="text" placeholder="예: color_adjust"></div>
1032:               </div>
1033:               <div class="batch-event-section" id="batchEventAnomalyFields" hidden>
1034:                 <div class="batch-event-field-grid two-col">
1035:                   <div class="batch-event-field"><label for="eventAnomalyCode">이상 코드</label><select id="eventAnomalyCode"></select></div>
1036:                   <div class="batch-event-field"><label for="eventAnomalySeverity">심각도</label><select id="eventAnomalySeverity"><option value="low">low</option><option value="medium" selected>medium</option><option value="high">high</option></select></div>
1037:                 </div>
1038:                 <div class="batch-event-field"><label for="eventAnomalyAction">즉시 조치</label><textarea id="eventAnomalyAction" placeholder="현장에서 바로 취한 조치"></textarea></div>
1039:                 <div class="batch-event-photo-row">
1040:                   <button type="button" class="batch-event-photo-btn" id="batchEventPhotoBtn">사진 촬영/선택</button>
1041:                   <button type="button" class="batch-event-photo-btn" id="batchEventUseLatestPhotoBtn">최근 갤러리 사진 사용</button>
1042:                   <span id="batchEventPhotoStatus" class="batch-event-photo-status">연결된 사진 없음</span>
1043:                   <input id="eventPhotoInput" type="file" accept="image/*" capture="environment" hidden>
1044:                 </div>
1045:               </div>
1046:               <div class="batch-event-section" id="batchEventScrapFields" hidden>
1047:                 <div class="batch-event-field-grid two-col">
1048:                   <div class="batch-event-field"><label for="eventScrapCount">폐기 수량 (ea)</label><input id="eventScrapCount" type="number" step="1" placeholder="4"></div>
1049:                   <div class="batch-event-field"><label for="eventScrapMass">폐기 질량 (g)</label><input id="eventScrapMass" type="number" step="0.1" placeholder="120"></div>
1050:                 </div>
1051:                 <div class="batch-event-field"><label for="eventScrapReason">폐기 사유</label><select id="eventScrapReason"></select></div>
1052:               </div>
1053:               <div class="batch-event-field"><label for="eventCommonNote">현장 메모</label><textarea id="eventCommonNote" placeholder="관찰 내용 · 불량 형태 · 추가 메모"></textarea></div>
1054:             </div>
1055:           </div>
1056:           <div class="batch-event-block batch-event-section" id="batchEventSnapshotBlock">
1057:             <h4>현재 조건 snapshot</h4>
1058:             <div class="batch-event-field-grid two-col">
1059:               <div class="batch-event-field"><label for="eventStateCylinder">실린더 온도 (°C)</label><input id="eventStateCylinder" type="number" step="0.1"></div>
1060:               <div class="batch-event-field"><label for="eventStateMold">금형 온도 (°C)</label><input id="eventStateMold" type="number" step="0.1"></div>
1061:               <div class="batch-event-field"><label for="eventStateSpeed">사출 속도 (mm/s)</label><input id="eventStateSpeed" type="number" step="0.1"></div>
1062:               <div class="batch-event-field"><label for="eventStatePressure">사출압력 (bar)</label><input id="eventStatePressure" type="number" step="0.1"></div>
1063:               <div class="batch-event-field"><label for="eventStatePacking">보압 (bar)</label><input id="eventStatePacking" type="number" step="0.1"></div>
1064:               <div class="batch-event-field"><label for="eventStateCooling">냉각 시간 (s)</label><input id="eventStateCooling" type="number" step="0.1"></div>
1065:             </div>
1066:           </div>
1067:         </div>
1068:         <div class="batch-event-actions">
1069:           <button type="button" class="batch-event-action-btn primary" id="batchEventSaveBtn">Add event · 추가</button>
1070:           <button type="button" class="batch-event-action-btn secondary" id="batchEventCancelBtn">Cancel · 취소</button>
1071:         </div>
1072:       </div>
1073:     </details>
1074:     <div class="batch-event-recent">
1075:       <h4>최근 배치 이벤트 (최신 5개)</h4>
1076:       <div id="batchEventRecentList" class="batch-event-recent-list">
1077:         <div class="batch-event-empty">아직 저장된 이벤트가 없습니다.</div>
1078:       </div>
1079:     </div>
1080:   `,
1081:   en: `
1082:     <details class="batch-event-sheet" id="batchEventSheet" open>
1083:       <summary class="batch-event-summary">
1084:         <strong>Log event · Event recorder</strong>
1085:         <span>Store snapshot, addition, anomaly, scrap, and note events inside the active batch session.</span>
1086:       </summary>
1087:       <div class="batch-event-body">
1088:         <div id="batchEventNotice" class="batch-event-notice">Start the batch first, then save field events as they happen.</div>
1089:         <div class="batch-event-kind-row" role="group" aria-label="Event kind">
1090:           <button type="button" class="batch-event-kind-btn" data-event-kind="temp_reading">Snapshot</button>
1091:           <button type="button" class="batch-event-kind-btn" data-event-kind="addition">Addition</button>
1092:           <button type="button" class="batch-event-kind-btn" data-event-kind="anomaly">Anomaly</button>
1093:           <button type="button" class="batch-event-kind-btn" data-event-kind="scrap">Scrap</button>
1094:           <button type="button" class="batch-event-kind-btn" data-event-kind="note">Note</button>
1095:         </div>
1096:         <div class="batch-event-grid">
1097:           <div class="batch-event-block">
1098:             <h4>Event payload</h4>
1099:             <div class="batch-event-field-grid">
1100:               <div class="batch-event-section" id="batchEventAdditionFields" hidden>
1101:                 <div class="batch-event-field-grid two-col">
1102:                   <div class="batch-event-field"><label for="eventAdditionMaterial">Material added</label><input id="eventAdditionMaterial" type="text" placeholder="e.g. talc"></div>
1103:                   <div class="batch-event-field"><label for="eventAdditionQty">Qty (g)</label><input id="eventAdditionQty" type="number" step="0.1" placeholder="50"></div>
1104:                 </div>
1105:                 <div class="batch-event-field"><label for="eventAdditionReason">Reason</label><input id="eventAdditionReason" type="text" placeholder="e.g. color_adjust"></div>
1106:               </div>
1107:               <div class="batch-event-section" id="batchEventAnomalyFields" hidden>
1108:                 <div class="batch-event-field-grid two-col">
1109:                   <div class="batch-event-field"><label for="eventAnomalyCode">Anomaly code</label><select id="eventAnomalyCode"></select></div>
1110:                   <div class="batch-event-field"><label for="eventAnomalySeverity">Severity</label><select id="eventAnomalySeverity"><option value="low">low</option><option value="medium" selected>medium</option><option value="high">high</option></select></div>
1111:                 </div>
1112:                 <div class="batch-event-field"><label for="eventAnomalyAction">Immediate action</label><textarea id="eventAnomalyAction" placeholder="What was done on the floor right away"></textarea></div>
1113:                 <div class="batch-event-photo-row">
1114:                   <button type="button" class="batch-event-photo-btn" id="batchEventPhotoBtn">Capture / choose photo</button>
1115:                   <button type="button" class="batch-event-photo-btn" id="batchEventUseLatestPhotoBtn">Use latest gallery photo</button>
1116:                   <span id="batchEventPhotoStatus" class="batch-event-photo-status">No photo linked yet.</span>
1117:                   <input id="eventPhotoInput" type="file" accept="image/*" capture="environment" hidden>
1118:                 </div>
1119:               </div>
1120:               <div class="batch-event-section" id="batchEventScrapFields" hidden>
1121:                 <div class="batch-event-field-grid two-col">
1122:                   <div class="batch-event-field"><label for="eventScrapCount">Rejected count (ea)</label><input id="eventScrapCount" type="number" step="1" placeholder="4"></div>
1123:                   <div class="batch-event-field"><label for="eventScrapMass">Rejected mass (g)</label><input id="eventScrapMass" type="number" step="0.1" placeholder="120"></div>
1124:                 </div>
1125:                 <div class="batch-event-field"><label for="eventScrapReason">Reason code</label><select id="eventScrapReason"></select></div>
1126:               </div>
1127:               <div class="batch-event-field"><label for="eventCommonNote">Floor note</label><textarea id="eventCommonNote" placeholder="Observation, defect pattern, or freeform note"></textarea></div>
1128:             </div>
1129:           </div>
1130:           <div class="batch-event-block batch-event-section" id="batchEventSnapshotBlock">
1131:             <h4>Current-state snapshot</h4>
1132:             <div class="batch-event-field-grid two-col">
1133:               <div class="batch-event-field"><label for="eventStateCylinder">Barrel temp (°C)</label><input id="eventStateCylinder" type="number" step="0.1"></div>
1134:               <div class="batch-event-field"><label for="eventStateMold">Mold temp (°C)</label><input id="eventStateMold" type="number" step="0.1"></div>
1135:               <div class="batch-event-field"><label for="eventStateSpeed">Injection speed (mm/s)</label><input id="eventStateSpeed" type="number" step="0.1"></div>
1136:               <div class="batch-event-field"><label for="eventStatePressure">Injection pressure (bar)</label><input id="eventStatePressure" type="number" step="0.1"></div>
1137:               <div class="batch-event-field"><label for="eventStatePacking">Packing pressure (bar)</label><input id="eventStatePacking" type="number" step="0.1"></div>
1138:               <div class="batch-event-field"><label for="eventStateCooling">Cooling time (s)</label><input id="eventStateCooling" type="number" step="0.1"></div>
1139:             </div>
1140:           </div>
1141:         </div>
1142:         <div class="batch-event-actions">
1143:           <button type="button" class="batch-event-action-btn primary" id="batchEventSaveBtn">Add event</button>
1144:           <button type="button" class="batch-event-action-btn secondary" id="batchEventCancelBtn">Cancel</button>
1145:         </div>
1146:       </div>
1147:     </details>
1148:     <div class="batch-event-recent">
1149:       <h4>Recent batch events (latest 5)</h4>
1150:       <div id="batchEventRecentList" class="batch-event-recent-list">
1151:         <div class="batch-event-empty">No batch events have been saved yet.</div>
1152:       </div>
1153:     </div>
1154:   `
1155: };
1156: const FLASH_TAB_HTML = {
1157:   ko: {
1158:     t0: `
1159:       <h3>플래시 점검의 출발점</h3><div class="success-box"><p><strong>불량이 생긴 위치와 충전·보압 중 발생 시점을 먼저 기록합니다.</strong></p><p>제조사 공정창 → 충전 시험 → V/P 확인 → 게이트 고화 시험 → 냉각·치수 확인 순서로 진행하세요.</p></div><p>공정 조건 탭에서 재료별 원문을 확인할 수 있습니다. 네 단계만으로 플래시를 방지하거나 일정 두께 이하로 보장할 수 없습니다.</p>
1160:     `,
1161:     t1: `
1162:       <h3>설비에 옮기기 전에</h3><div class="success-box"><p><strong>배럴 설정온도와 실제 용융온도를 구분하세요.</strong></p><p>사출속도 %는 장비 상대값입니다. mm/s·유량·충전시간으로 대응을 확인하고, 수지압·유압·캐비티 압력을 구분합니다.</p></div><p>PHA 전체에 적용할 수 있는 V0/V1 고정속도·압력비는 확인되지 않았습니다. V/P 위치는 충전 형상·중량·쿠션과 압력 응답으로 정합니다.</p>
1163:     `,
1164:     t2: `
1165:       <h3 style="color:var(--ink);margin-bottom:20px">설정값 계산기 (4개 · 입력하면 자동 권장값 산출)</h3>
1166:       <div class="calculator">
1167:         <h3 style="color:var(--ink);margin-bottom:20px">1. 클램프 톤수 계산기 (Clamp Tonnage)</h3>
1168:         <div class="calc-input-group"><label>캐비티 평균 압력 P_avg (bar) — 충전·보압 중 최대 형개력 시점의 면적 평균압력</label><input type="number" id="flash-p-avg" placeholder="예: 500" value="500"></div>
1169:         <div class="calc-input-group"><label>총 투영 면적 A_proj (cm²) — 모든 캐비티 + 러너</label><input type="number" id="flash-a-proj" placeholder="예: 2000" value="2000"></div>
1170:         <p style="font-size:13px;color:var(--muted);margin:8px 0 14px">※ 형체력(tf) = 총 투영 면적(cm²) × 캐비티 평균압력(bar) / 980.665. 첫 추정치는 산식 기준 + 20 % 여유이며, 실제 보압까지 고려해 최종 확정하세요.</p>
1171:         <button class="calc-button" onclick="calculateFlashClampTonnage()">계산하기</button>
1172:         <button class="calc-button" onclick="clearFlashInputs('clamp')">초기화</button>
1173:         <div class="calc-result" id="flash-clamp-result" style="display:none;"><h4>계산 결과</h4><div class="calc-result-value" id="flash-clamp-value"></div><p id="flash-clamp-recommendation"></p></div>
1174:       </div>
1175:       <div class="calculator">
1176:         <h3 style="color:var(--ink);margin-bottom:20px">2. 캐비티 압력 역산 계산기 (Runner Protection Cap)</h3>
1177:         <div class="calc-input-group"><label>클램프 한계 (ton-force) — 기계 스펙에 적힌 최대 클램프 힘</label><input type="number" id="flash-f-clamp" placeholder="예: 1200" value="1200"></div>
1178:         <div class="calc-input-group"><label>제품 투영 면적 A_proj (cm²)</label><input type="number" id="flash-a-proj-2" placeholder="예: 2000" value="2000"></div>
1179:         <div class="calc-input-group"><label>안전 계수 (권장 0.8 · 클램프 여유 20% 확보)</label><input type="number" id="flash-safety-factor" placeholder="0.8" value="0.8" step="0.05"></div>
1180:         <button class="calc-button" onclick="calculateFlashPressureLimit()">계산하기</button>
1181:         <button class="calc-button" onclick="clearFlashInputs('pressure')">초기화</button>
1182:         <div class="calc-result" id="flash-pressure-result" style="display:none;"><h4>캐비티 압력 역산 추천값</h4><div class="calc-result-value" id="flash-pressure-value"></div><p id="flash-pressure-recommendation"></p></div>
1183:       </div>
1184:       <div class="calculator">
1185:         <h3 style="color:var(--ink);margin-bottom:20px">3. 러너 전단률 계산기 (Runner Shear Rate)</h3>
1186:         <div class="calc-input-group"><label>체적 유량 Q (cm³/s) — 단위 시간당 러너를 통과하는 수지 부피</label><input type="number" id="flash-flow-rate" placeholder="예: 50" value="50"></div>
1187:         <div class="calc-input-group"><label>러너 반경 R (cm) — 원통형 러너 기준</label><input type="number" id="flash-runner-radius" placeholder="예: 0.4" value="0.4" step="0.1"></div>
1188:         <button class="calc-button" onclick="calculateFlashShearRate()">계산하기</button>
1189:         <button class="calc-button" onclick="clearFlashInputs('shear')">초기화</button>
1190:         <div class="calc-result" id="flash-shear-result" style="display:none;"><h4>러너 벽면 전단률 (γ̇ at wall)</h4><div class="calc-result-value" id="flash-shear-value"></div><p id="flash-shear-recommendation"></p></div>
1191:       </div>
1192:       <div class="calculator">
1193:         <h3 style="color:var(--ink);margin-bottom:20px">4. 보압 설정값 계산기 (P1 · P2 Auto-Split)</h3>
1194:         <div class="calc-input-group"><label>최대 사출압 P_inj_peak (bar) — 이번 샷에서 관측된 피크값</label><input type="number" id="flash-p-inj-peak" placeholder="예: 1500" value="1500"></div>
1195:         <button class="calc-button" onclick="calculateFlashPackingPressure()">계산하기</button>
1196:         <button class="calc-button" onclick="clearFlashInputs('packing')">초기화</button>
1197:         <div class="calc-result" id="flash-packing-result" style="display:none;"><h4>보압 설정 권장값 (P1 · P2 분리 출력)</h4><div class="calc-result-value" id="flash-packing-value"></div><p id="flash-packing-recommendation"></p></div>
1198:       </div>
1199:     `,
1200:     t3: `
1201:       <h3>사출 공정 흐름</h3><div class="success-box"><p><strong>공급·가소화 → 충전 → 보압·냉각 → 탈형·검사</strong></p><p>초록색은 수지의 흐름입니다. 설비 형상과 배치는 개념도입니다.</p></div><img src="assets/equipment/injection.png?v=15" width="1280" height="640" style="width:100%;height:auto" alt="Conceptual injection equipment"><p>공정 단계마다 설정값과 관찰값을 분리해 기록하세요. 흐름도는 시간·속도·압력의 검증된 설정지가 아닙니다.</p>
1202:     `,
1203:     t4: `
1204:       <h3>시운전 전 확인</h3><div class="success-box"><p><strong>재료·lot·배합과 원료/컴파운드 여부를 확인합니다.</strong></p><p>건조조건은 해당 TDS를 따릅니다. A1000P 본문은 50 °C 미만, S1000P는 80 °C × 5 h입니다. 서로 그대로 옮겨 쓰지 마세요.</p></div><p>금형 접촉면·벤트·온조기 성능, 형체력과 압력 기준을 확인하고, 비교할 중량·치수·외관 기준을 정합니다.</p>
1205:     `,
1206:     t5: `
1207:       <h3>증상에서 점검으로</h3><div class="success-box"><p><strong>플래시: 금형 틈새·손상과 발생 단계를 먼저 확인합니다.</strong></p><p>쇼트 샷: 공급·벤트·게이트·압력 제한·충전 패턴을 확인합니다. 표면 꺼짐: 게이트 고화·두께·보압 전달을 확인합니다.</p></div><p>갈변·스트랜드 약화·압력 하강이 함께 나타나면 건조 이력과 고온 체류를 확인하세요. 형체력이나 온도를 일률적으로 올리지 말고 현장 절차로 조치합니다.</p>
1208:     `,
1209:     t6: `
1210:       <h3 style="color:var(--ink);margin-bottom:20px">공정 조건 현장 기록 로그 (배치 단위 · 템플릿 · 사진 · 차트)</h3>
1211:       <div class="success-box">
1212:         <h3>현장에서 즉시 조건 기록</h3>
1213:         <p><strong>공정 조건·관찰한 현상을 실시간으로 기록</strong> → 문제 해결 · 최적화에 활용.</p>
1214:         <p>각 파라미터는 <strong>숫자 직접 입력</strong> 또는 <strong>+/- 버튼</strong>으로 조정. 입력값은 <strong>자동 저장</strong>.</p>
1215:       </div>
1216:       ${FLASH_BATCH_CONTEXT_BANNER.ko}
1217:       ${FLASH_EVENT_LOGGER_PANEL.ko}
1218:       <div class="filter-container">
1219:         <h4 style="color:var(--ink);margin-bottom:10px">검색 · 필터</h4>
1220:         <div class="filter-row">
1221:           <input type="text" id="filterKeyword" class="filter-input" placeholder="비고란 키워드 검색..." onkeyup="filterProcessLog()">
1222:           <input type="date" id="filterDateFrom" class="filter-input" style="max-width:180px" onchange="filterProcessLog()">
1223:           <span style="white-space:nowrap">~</span>
1224:           <input type="date" id="filterDateTo" class="filter-input" style="max-width:180px" onchange="filterProcessLog()">
1225:           <button class="btn-filter" onclick="clearFilter()">필터 초기화</button>
1226:         </div>
1227:       </div>
1228:       <div class="template-container">
1229:         <h4 style="color:var(--ink);margin-bottom:5px">템플릿 관리 (자주 쓰는 조건 저장)</h4>
1230:         <p style="font-size:13px;color:var(--muted);margin-bottom:10px">자주 쓰는 조건을 템플릿으로 저장 → 다음번에 빠르게 불러오기.</p>
1231:         <div class="template-buttons">
1232:           <button class="btn-template" onclick="saveTemplate()">지금 조건을 템플릿으로 저장</button>
1233:           <button class="btn-template load" onclick="loadTemplate()">템플릿 불러오기</button>
1234:           <button class="btn-template delete" onclick="manageTemplates()">템플릿 목록 · 삭제</button>
1235:         </div>
1236:       </div>
1237:       <div class="calc-recommendation">
1238:         <h4>무게 측정 · 샷 계량 계산기</h4>
1239:         <p style="font-size:14px;margin-bottom:15px">제품 · 러너 무게를 입력하면 ① <strong>샷 계량</strong> ② <strong>플래시 저감 조건 추천</strong>이 자동으로 계산됩니다.</p>
1240:         <div class="weight-calc-grid">
1241:           <div class="weight-input-box"><label>제품 1개 무게 (g)</label><input type="number" id="partWeight" step="0.01" placeholder="0.00" onchange="calculateShotWeight()"></div>
1242:           <div class="weight-input-box"><label>러너 무게 (g)</label><input type="number" id="runnerWeight" step="0.01" placeholder="0.00" onchange="calculateShotWeight()"></div>
1243:           <div class="weight-input-box"><label>캐비티 수</label><input type="number" id="cavityCount" value="36" step="1" onchange="calculateShotWeight()"></div>
1244:           <div class="weight-input-box"><label>재료 밀도 (g/cm³)</label><input type="number" id="materialDensity" value="1.25" step="0.01" placeholder="1.25" onchange="calculateShotWeight()"><button class="btn-filter" style="margin-top:8px;width:100%;padding:6px" onclick="loadDensityFromGrade()" title="물성 DB 탭에 등록된 해당 그레이드의 밀도가 자동으로 입력됩니다.">선택한 Grade의 밀도 불러오기</button></div>
1245:         </div>
1246:         <p style="font-size:13px;color:var(--muted);margin:10px 0 0">※ 총 샷 계량 = 제품 1개 무게 × 캐비티 수 + 러너 무게. 밀도를 입력하면 샷 용적까지 함께 계산됩니다.</p>
1247:         <div id="shotWeightResult" style="display:none;margin-top:15px">
1248:           <div class="density-display">총 샷 계량: <span id="totalShotWeight">0.00</span> g (<span id="shotVolume">0.00</span> cm³)</div>
1249:           <button class="btn-log-action btn-add-log" style="width:100%;margin-top:10px" onclick="applyWeightToLog()">최신 로그에 이 값 적용</button>
1250:         </div>
1251:       </div>
1252:       <div id="flashRecommendations" style="display:none">
1253:         <div class="calc-recommendation">
1254:           <h4>플래시 저감 조건 — 자동 분석</h4>
1255:           <p style="font-size:14px;margin-bottom:15px">최신 로그 1건의 공정 조건을 기준으로 플래시를 줄일 방향을 제안합니다. 추천치는 단일 로그 기준이므로 3-5샷 평균을 별도 확인하세요.</p>
1256:           <div id="recommendationContent"></div>
1257:         </div>
1258:       </div>
1259:       <div class="chart-container">
1260:         <div class="chart-controls">
1261:           <h4 style="color:var(--ink);margin:0;flex:1">공정 조건 트렌드 차트 (최근 20개)</h4>
1262:           <button class="chart-toggle-btn active" onclick="showChart('temp')" id="chartBtnTemp">온도</button>
1263:           <button class="chart-toggle-btn" onclick="showChart('pressure')" id="chartBtnPressure">압력</button>
1264:           <button class="chart-toggle-btn" onclick="showChart('weight')" id="chartBtnWeight">무게</button>
1265:           <button class="chart-toggle-btn" onclick="showChart('time')" id="chartBtnTime">시간</button>
1266:         </div>
1267:         <div style="position:relative;height:300px"><canvas id="processChart"></canvas></div>
1268:         <p style="font-size:12px;color:var(--muted);margin-top:10px;text-align:center">최근 20개 로그로 트렌드 표시. 로그가 추가되면 <strong>자동 갱신</strong>.</p>
1269:       </div>
1270:       <div class="log-container">
1271:         <div class="log-header">
1272:           <h4 style="color:var(--ink);margin:0">공정 조건 로그 테이블</h4>
1273:           <div style="display:flex;gap:10px;flex-wrap:wrap">
1274:             <button class="btn-log-action btn-add-log" onclick="addProcessLogEntry()">새 행 추가</button>
1275:             <button class="btn-log-action btn-export-log" onclick="exportProcessLog()">CSV로 내보내기</button>
1276:             <button class="btn-log-action btn-clear-log" onclick="clearProcessLog()">전체 삭제</button>
1277:           </div>
1278:         </div>
1279:         <div style="overflow-x:auto">
1280:           <table class="log-table" id="processLogTable">
1281:             <thead>
1282:               <tr>
1283:                 <th style="min-width:140px">일시 · Time</th>
1284:                 <th style="min-width:120px">배치 · Batch</th>
1285:                 <th style="min-width:160px">조성 · Composition</th>
1286:                 <th style="min-width:120px">실린더 온도 · Barrel (°C)</th>
1287:                 <th style="min-width:120px">금형 온도 · Mold (°C)</th>
1288:                 <th style="min-width:130px">사출속도 · Inj. speed (mm/s)</th>
1289:                 <th style="min-width:120px">사출압력 · Inj. pressure (bar)</th>
1290:                 <th style="min-width:120px">보압 · Packing (bar)</th>
1291:                 <th style="min-width:130px">보압시간 · Packing time (s)</th>
1292:                 <th style="min-width:130px">냉각시간 · Cooling (s)</th>
1293:                 <th style="min-width:120px">제품 무게 · Part (g)</th>
1294:                 <th style="min-width:120px">러너 무게 · Runner (g)</th>
1295:                 <th style="min-width:130px">총 무게 · Total (g)</th>
1296:                 <th style="min-width:200px">비고 · Notes</th>
1297:                 <th style="min-width:100px">사진 · Photo</th>
1298:                 <th style="min-width:80px">동작 · Actions</th>
1299:               </tr>
1300:             </thead>
1301:             <tbody id="processLogBody"><tr><td colspan="16" class="log-empty">아직 로그가 없습니다. <strong>"새 행 추가"</strong> 버튼으로 첫 기록을 시작하세요.</td></tr></tbody>
1302:           </table>
1303:         </div>
1304:       </div>
1305:       <div class="info-box" style="margin-top:30px">
1306:         <h3>사용 안내 (빠른 참조)</h3>
1307:         <ul style="margin-left:20px;margin-top:10px">
1308:           <li><strong>로그 추가</strong> · "새 행 추가" 버튼 → 빈 행 1개 추가</li>
1309:           <li><strong>값 입력</strong> · 숫자 직접 타이핑 또는 +/- 버튼</li>
1310:           <li><strong>무게 측정</strong> · 제품·러너 무게 입력 → 샷 계량 + 플래시 추천 자동 산출</li>
1311:           <li><strong>검색 · 필터</strong> · 날짜 범위 + 키워드로 빠른 검색</li>
1312:           <li><strong>템플릿</strong> · 자주 쓰는 조건을 저장해 재사용</li>
1313:           <li><strong>사진 첨부</strong> · 각 로그에 제품 · 불량 사진 첨부</li>
1314:           <li><strong>차트 뷰</strong> · 온도·압력·무게·시간 트렌드를 실시간 차트로 확인</li>
1315:           <li><strong>모바일 사용</strong> · PC · 휴대폰 모두에서 편리하게 사용</li>
        ```
