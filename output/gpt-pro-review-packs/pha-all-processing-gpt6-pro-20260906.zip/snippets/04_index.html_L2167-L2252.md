        # Snippet

        - Path: `index.html`
        - Lines: `2167-2252`
        - Reason: Flash-control calculations

        ```html
        2167: function calculateFlashClampTonnage() {
2168:   $('flash-clamp-result').style.display='none';
2169:   const pAvg = parseFloat($('flash-p-avg').value);
2170:   const aProj = parseFloat($('flash-a-proj').value);
2171:   if (isNaN(pAvg) || isNaN(aProj)) {
2172:     alert(_t('input_all'));
2173:     return;
2174:   }
2175:   const result=PHAEvidence.clamp(pAvg,aProj); if(result.error){$('flash-clamp-result').style.display='none';alert(result.error);return;}
2176:   const tonnage = result.tf;
2177:   const recommended = tonnage * 1.2;
2178:   $('flash-clamp-result').style.display = 'block';
2179:   $('flash-clamp-value').textContent = tonnage.toFixed(1) + ' tf';
2180:   $('flash-clamp-recommendation').innerHTML = LANG === 'ko'
2181:     ? `<strong>권장 클램프 톤수 (20% 여유):</strong> ${recommended.toFixed(1)} tf<br>현재 기계의 클램프 톤수가 ${recommended.toFixed(1)} tf 이상인지 확인하세요.`
2182:     : `<strong>Recommended clamp tonnage (20% margin):</strong> ${recommended.toFixed(1)} tf<br>Confirm the machine's clamp tonnage is at least ${recommended.toFixed(1)} tf.`;
2183: }
2184: 
2185: function calculateFlashPressureLimit() {
2186:   $('flash-pressure-result').style.display='none';
2187:   const fClamp = parseFloat($('flash-f-clamp').value);
2188:   const aProj = parseFloat($('flash-a-proj-2').value);
2189:   const safetyFactor = parseFloat($('flash-safety-factor').value);
2190:   if (isNaN(fClamp) || isNaN(aProj) || isNaN(safetyFactor)) {
2191:     alert(_t('input_all'));
2192:     return;
2193:   }
2194:   const result=PHAEvidence.cavityPressure(fClamp,aProj,safetyFactor); if(result.error){$('flash-pressure-result').style.display='none';alert(result.error);return;}
2195:   const pressureLimit = result.bar;
2196:   $('flash-pressure-result').style.display = 'block';
2197:   $('flash-pressure-value').textContent = pressureLimit.toFixed(1) + ' bar';
2198:   $('flash-pressure-recommendation').innerHTML = LANG === 'ko'
2199:     ? `<strong>금형 내 평균압력의 역산 참고값입니다.</strong><br>형체력 이용률 ${(safetyFactor * 100).toFixed(0)}% 기준. 사출기 수지압·유압 설정값으로 직접 입력하지 마세요. 러너 손실·캐비티 압력 분포와 금형 상태를 별도 확인하세요.`
2200:     : `<strong>Estimated mean cavity-pressure capacity.</strong><br>Based on ${(safetyFactor * 100).toFixed(0)}% clamp utilization. Do not enter it as a machine plastic or hydraulic pressure setting. Check runner losses, cavity distribution and mold condition separately.`;
2201: }
2202: 
2203: function calculateFlashShearRate() {
2204:   $('flash-shear-result').style.display='none';
2205:   const Q = parseFloat($('flash-flow-rate').value);
2206:   const R = parseFloat($('flash-runner-radius').value);
2207:   if (!(Q>0) || !(R>0) || !Number.isFinite(Q) || !Number.isFinite(R)) {
2208:     alert(_t('input_all'));
2209:     return;
2210:   }
2211:   const shearRate = (4 * Q) / (Math.PI * Math.pow(R, 3));
2212:   let recommendation = '';
2213:   if (shearRate > 50000) {
2214:     recommendation = LANG === 'ko'
2215:       ? '<strong>경고:</strong> 전단률이 매우 높습니다 (&gt;50,000 s⁻¹). V0 속도를 낮추거나 러너 직경을 키우세요.'
2216:       : '<strong>Warning:</strong> shear rate is very high (&gt;50,000 s⁻¹). Lower V0 speed or widen the runner diameter.';
2217:   } else if (shearRate > 20000) {
2218:     recommendation = LANG === 'ko'
2219:       ? '<strong>주의:</strong> 전단률이 높은 편입니다 (&gt;20,000 s⁻¹). 계속 모니터링하세요.'
2220:       : '<strong>Caution:</strong> shear rate is elevated (&gt;20,000 s⁻¹). Monitor this closely.';
2221:   } else {
2222:     recommendation = LANG === 'ko'
2223:       ? '<strong>양호:</strong> 전단률이 적정 범위입니다.'
2224:       : '<strong>Good:</strong> shear rate is within the acceptable range.';
2225:   }
2226:   recommendation=LANG==='ko'?'원형 유로의 겉보기 전단률입니다. 비뉴턴 보정·분기 유량 미반영. 그레이드별 실측과 대조하세요.':'Apparent shear rate in a circular channel. No non-Newtonian or branch-flow correction; compare with grade-specific measurements.';
2227:   $('flash-shear-result').style.display = 'block';
2228:   $('flash-shear-value').textContent = shearRate.toFixed(0) + ' s⁻¹';
2229:   $('flash-shear-recommendation').innerHTML = recommendation;
2230: }
2231: 
2232: function calculateFlashPackingPressure() {
2233:   $('flash-packing-result').style.display='none';
2234:   const pInjPeak = parseFloat($('flash-p-inj-peak').value);
2235:   if (!(pInjPeak>0) || !Number.isFinite(pInjPeak)) {
2236:     alert(_t('input_peak'));
2237:     return;
2238:   }
2239:   const p1Min = pInjPeak * 0.30;
2240:   const p1Max = pInjPeak * 0.45;
2241:   const p2Min = pInjPeak * 0.15;
2242:   const p2Max = pInjPeak * 0.30;
2243:   $('flash-packing-result').style.display = 'block';
2244:   $('flash-packing-value').innerHTML =
2245:     `P1: ${p1Min.toFixed(0)} - ${p1Max.toFixed(0)} bar<br>` +
2246:     `P2: ${p2Min.toFixed(0)} - ${p2Max.toFixed(0)} bar`;
2247:   $('flash-packing-recommendation').innerHTML = LANG === 'ko'
2248:     ? `<strong>P1 단계:</strong> ${p1Min.toFixed(0)}-${p1Max.toFixed(0)} bar는 동일 압력 기준의 비율 예시입니다. 단계 시간은 실측으로 정합니다.<br><strong>P2 단계:</strong> ${p2Min.toFixed(0)}-${p2Max.toFixed(0)} bar를 게이트 동결까지 유지합니다.<br>게이트 시일 시험으로 정확한 종료 시점을 결정하세요.`
2249:     : `<strong>P1:</strong> hold ${p1Min.toFixed(0)}-${p1Max.toFixed(0)} bar is a ratio example on the same pressure basis; establish stage times from measurements.<br><strong>P2:</strong> hold ${p2Min.toFixed(0)}-${p2Max.toFixed(0)} bar until gate seal.<br>Use the gate-seal test to determine the exact cutoff timing.`;
2250: }
2251: 
2252: function clearFlashInputs(type) {
        ```
