        # Snippet

        - Path: `pha-integration.js`
        - Lines: `39-105`
        - Reason: Grade-to-composition classification

        ```js
         39:     if(grade==='CB0104A'||grade==='CB0400A'){
 40:       info.subtype='PHA/mineral compound';info.notes_ko='배합비는 별도 확인';info.notes_en='Verify the exact formulation';
 41:     }
 42:     if(grade==='CaCO3'){info.notes_ko='탄산칼슘 충전재 · 수분/표면처리 확인';info.notes_en='Calcium carbonate filler; verify moisture/surface treatment';}
 43:     if(grade==='P3HB'){info.notes_ko='고융점·열 이력 확인';info.notes_en='Check melting behavior and thermal history';}
 44:   });
 45: 
 46:   /* ── Helpers ──────────────────────────────────────────────────────────── */
 47: 
 48:   function t(ko, en) { return (typeof LANG !== 'undefined' && LANG === 'en') ? en : ko; }
 49:   function el(id)    { return document.getElementById(id); }
 50:   function escHtml(str) {
 51:     return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
 52:   }
 53: 
 54:   /* ── P2: Temperature auto-suggestion ─────────────────────────────────── */
 55: 
 56:   function getTemperatureSuggestion(grade) {
 57:     const record=window.PHAEvidence?.GRADES[grade];
 58:     return {barrelPeak:null,dryTemp:null,dryTime:null,reference:record||null,
 59:       warnings:record?[]:[t('공정조건 원문 미확인 — 물성으로 설정값을 자동 추정하지 않습니다.','Processing source unverified — properties are not converted into setpoints.')]};
 60:   }
 61: 
 62:   /* ── P3: H/S/F auto-classification ───────────────────────────────────── */
 63: 
 64:   function autoClassifyGrade(grade) {
 65:     const warnings  = [];
 66:     const components = [];
 67: 
 68:     // Direct registry lookup
 69:     const info = PHA_MATERIAL_REGISTRY[grade];
 70:     if (info && ['H','S','F'].includes(info.type)) {
 71:       components.push({ name: grade, type: info.type, wt_pct: 100 });
 72:       if (info.type === 'S') warnings.push(t('원료별 건조 조건과 컴파운드 조건을 구분하세요.', 'Distinguish raw-resin and compound drying conditions.'));
 73:       return { components, warnings };
 74:     }
 75: 
 76:     // A commercial compound name does not disclose its exact component percentages.
 77:     if (/^C[AB]\d/.test(grade)) {
 78:       warnings.push(t('상용 컴파운드의 정확한 배합비는 공개 자료로 확인되지 않았습니다. 배합표를 확인해 직접 입력하세요.', 'The exact commercial-compound recipe is not disclosed by the reference. Enter the verified formulation manually.'));
 79:       return { components, warnings };
 80:     }
 81: 
 82:     // Blend patterns: PLA_aPHA, PHA_PBAT, PHA_PBS, PHA_PBSA
 83:     const blendDef = [
 84:       [/^PLA_aPHA_(\d+)_(\d+)$/i,  ['PLA', 'H'],    ['A1000P', 'S']],
 85:       [/^PHA_PBAT_(\d+)_(\d+)$/i,  ['S1000P', 'H'], ['PBAT', 'S']  ],
 86:       [/^PHA_PBS_(\d+)_(\d+)$/i,   ['S1000P', 'H'], ['PBS', 'S']   ],
 87:       [/^PHA_PBSA_(\d+)_(\d+)$/i,  ['S1000P', 'H'], ['PBSA', 'S']  ],
 88:     ];
 89:     for (const [rx, h, s] of blendDef) {
 90:       const m = grade.match(rx);
 91:       if (m) {
 92:         const hp = parseInt(m[1], 10), sp = parseInt(m[2], 10);
 93:         components.push({ name: h[0], type: h[1], wt_pct: hp }, { name: s[0], type: s[1], wt_pct: sp });
 94:         if (sp >= 20) warnings.push(t('Soft phase ≥20wt% → Type B 스크류 권장.', 'Soft phase ≥20wt% → Type B screw recommended.'));
 95:         return { components, warnings };
 96:       }
 97:     }
 98: 
 99:     // Commodity fallback
100:     const single = { PLA: 'H', PBAT: 'S', PBS: 'S', PBSA: 'S' };
101:     if (single[grade]) { components.push({ name: grade, type: single[grade], wt_pct: 100 }); return { components, warnings }; }
102: 
103:     warnings.push(t(`미등록 grade "${grade}" — 배합표 확인 필요.`, `Unknown grade "${grade}" — verify the formulation.`));
104:     return { components, warnings };
105:   }
        ```
