        # Snippet

        - Path: `index.html`
        - Lines: `1609-1761`
        - Reason: Grade mapping, six-process ranges, schemas and legacy fallback troubleshooting

        ```html
        1609: /* ========= Base profiles ========= */
1610: const BASE={PHA_SEMI:'PHA_SEMI',PHA_AMOR:'PHA_AMOR',PLA:'PLA',PBAT:'PBAT',PBS:'PBS',PBSA:'PBSA',PHA_PLA:'PHA_PLA',PHA_PBS:'PHA_PBS',PHA_PBAT:'PHA_PBAT'};
1611: 
1612: /* ========= Grade list ========= */
1613: const GRADES=[
1614:   {value:'S1000P',label:'S1000P (Semi-crystalline PHA)',profile:BASE.PHA_SEMI},
1615:   {value:'A1000P',label:'A1000P (Amorphous PHA)',profile:BASE.PHA_AMOR},
1616:   {value:'CB0400A',label:'CB0400A (PHA/mineral compound · Extrusion)',profile:BASE.PHA_SEMI},
1617:   {value:'CB0104A',label:'CB0104A (PHA/mineral compound · Injection)',profile:BASE.PHA_AMOR},
1618:   /* PLA/aPHA family (from website TDS list mentioned) */
1619:   {value:'CA1180P',label:'CA1180P (PLA/aPHA – Injection)',profile:BASE.PHA_PLA},
1620:   {value:'CA1170A',label:'CA1170A (PLA/aPHA – Injection)',profile:BASE.PHA_PLA},
1621:   {value:'CA1165A',label:'CA1165A (PLA/aPHA – Injection)',profile:BASE.PHA_PLA},
1622:   {value:'CA1670P',label:'CA1670P (PLA/aPHA – Sheet/Blow Molding)',profile:BASE.PHA_PLA},
1623:   {value:'CA1680', label:'CA1680 (PLA/aPHA – Sheet/Blow Molding)',profile:BASE.PHA_PLA},
1624:   {value:'CA1270P',label:'CA1270P (PLA/aPHA – Sheet)',profile:BASE.PHA_PLA},
1625:   /* blends + commodity */
1626:   {value:'PLA_aPHA_90_10',label:'PLA/aPHA (A1000P 10%)',profile:BASE.PHA_PLA},
1627:   {value:'PLA_aPHA_80_20',label:'PLA/aPHA (A1000P 20%)',profile:BASE.PHA_PLA},
1628:   {value:'PHA_PBSA_70_30',label:'PHA/PBSA (70/30)',profile:BASE.PBSA},
1629:   {value:'PHA_PBSA_50_50',label:'PHA/PBSA (50/50)',profile:BASE.PBSA},
1630:   {value:'PHA_PBS_70_30',label:'PHA/PBS (70/30)',profile:BASE.PHA_PBS},
1631:   {value:'PHA_PBS_50_50',label:'PHA/PBS (50/50)',profile:BASE.PHA_PBS},
1632:   {value:'PHA_PBAT_70_30',label:'PHA/PBAT (70/30)',profile:BASE.PHA_PBAT},
1633:   {value:'PHA_PBAT_50_50',label:'PHA/PBAT (50/50)',profile:BASE.PHA_PBAT},
1634:   {value:'PLA',label:'PLA',profile:BASE.PLA},
1635:   {value:'PBAT',label:'PBAT',profile:BASE.PBAT},
1636:   {value:'PBS',label:'PBS',profile:BASE.PBS},
1637:   {value:'PBSA',label:'PBSA',profile:BASE.PBSA},
1638: ];
1639: 
1640: /* ========= Recommended ranges ========= */
1641: const RECO={
1642:   [BASE.PHA_SEMI]:{
1643:     extrusion:{zone1:[140,155],zone2:[150,165],zone3:[160,170],zone4:[165,175],die:[165,180],screwRPM:[40,90],meltPressBar:[60,150],coolingRoll:[15,25],lineSpeed:[5,30]},
1644:     sheet:{zone1:[140,155],zone2:[150,165],zone3:[160,170],zone4:[165,175],zone5:[165,180],die:[170,180],chillTop:[15,25],chillMid:[15,25],chillBot:[15,25],rollRPM:[10,40],lineSpeed:[5,30],targetThickness:[200,2000],meltPressBar:[60,150]},
1645:     injection:{barrel1:[150,160],barrel2:[155,165],barrel3:[160,170],nozzle:[165,175],mold:[25,45],injSpeed:[30,120],injPressMPa:[60,120],packPressMPa:[30,70],packTime:[5,20],coolTime:[10,40],backPressBar:[30,80],screwRPM:[30,100],hold1P:[30,60],hold1T:[2,10],hold2P:[20,50],hold2T:[2,10]},
1646:     blownfilm:{zone1:[145,155],zone2:[155,165],zone3:[160,170],zone4:[165,175],die:[165,175],bur:[1.8,3.0],flh:[200,600],takeup:[10,60],dieGap:[0.8,1.5],meltPressBar:[80,180],airTemp:[15,25]},
1647:     blowmolding:{zone1:[150,160],zone2:[155,165],zone3:[160,170],head:[165,175],die:[165,175],accHead:[165,175],blowPressBar:[6,12],preBlowBar:[2,6],mold:[20,35],coolTime:[20,80]},
1648:     castfilm:{zone1:[150,160],zone2:[155,165],zone3:[160,170],die:[170,180],chillTop:[10,18],lineSpeed:[10,50],targetThickness:[20,200],meltPressBar:[60,150]}
1649:   },
1650:   [BASE.PHA_AMOR]:{
1651:     extrusion:{zone1:[130,145],zone2:[140,155],zone3:[150,165],zone4:[155,170],die:[160,170],screwRPM:[40,90],meltPressBar:[50,130],coolingRoll:[15,25],lineSpeed:[5,30]},
1652:     sheet:{zone1:[130,145],zone2:[140,155],zone3:[150,160],zone4:[155,165],zone5:[155,170],die:[160,170],chillTop:[15,25],chillMid:[15,25],chillBot:[15,25],rollRPM:[10,35],lineSpeed:[5,30],targetThickness:[200,2000],meltPressBar:[50,130]},
1653:     injection:{barrel1:[140,155],barrel2:[150,160],barrel3:[155,165],nozzle:[160,170],mold:[20,40],injSpeed:[30,120],injPressMPa:[50,100],packPressMPa:[25,60],packTime:[5,20],coolTime:[8,35],backPressBar:[20,60],screwRPM:[30,90],hold1P:[25,55],hold1T:[2,10],hold2P:[15,45],hold2T:[2,10]},
1654:     blownfilm:{zone1:[135,145],zone2:[145,155],zone3:[150,160],zone4:[155,165],die:[160,165],bur:[1.8,3.0],flh:[200,600],takeup:[10,60],dieGap:[0.8,1.5],meltPressBar:[70,160],airTemp:[15,25]},
1655:     blowmolding:{zone1:[140,150],zone2:[150,160],zone3:[155,165],head:[160,170],die:[160,170],accHead:[160,170],blowPressBar:[6,12],preBlowBar:[2,6],mold:[20,35],coolTime:[20,70]},
1656:     castfilm:{zone1:[140,150],zone2:[145,155],zone3:[150,160],die:[160,170],chillTop:[10,18],lineSpeed:[10,50],targetThickness:[20,200],meltPressBar:[50,130]}
1657:   },
1658:   [BASE.PLA]:{
1659:     extrusion:{zone1:[170,180],zone2:[180,190],zone3:[190,200],zone4:[195,205],die:[195,210],screwRPM:[40,80],meltPressBar:[70,150],coolingRoll:[15,25],lineSpeed:[5,30]},
1660:     sheet:{zone1:[170,180],zone2:[180,190],zone3:[190,200],zone4:[195,205],zone5:[195,210],die:[200,210],chillTop:[15,25],chillMid:[15,25],chillBot:[15,25],rollRPM:[10,35],lineSpeed:[5,25],targetThickness:[200,2000],meltPressBar:[70,150]},
1661:     injection:{barrel1:[180,190],barrel2:[190,200],barrel3:[195,205],nozzle:[200,210],mold:[20,35],injSpeed:[30,120],injPressMPa:[70,130],packPressMPa:[40,80],packTime:[5,20],coolTime:[10,40],backPressBar:[30,90],screwRPM:[30,90],hold1P:[40,80],hold1T:[2,10],hold2P:[30,70],hold2T:[2,10]},
1662:     blownfilm:{zone1:[175,185],zone2:[185,195],zone3:[190,200],zone4:[195,205],die:[200,210],bur:[1.8,3.0],flh:[200,600],takeup:[10,60],dieGap:[0.8,1.5],meltPressBar:[80,180],airTemp:[15,25]},
1663:     blowmolding:{zone1:[175,185],zone2:[185,195],zone3:[190,200],head:[200,210],die:[200,210],accHead:[200,210],blowPressBar:[6,12],preBlowBar:[2,6],mold:[15,25],coolTime:[20,80]},
1664:     castfilm:{zone1:[180,190],zone2:[190,200],zone3:[195,205],die:[200,210],chillTop:[10,18],lineSpeed:[10,40],targetThickness:[20,200],meltPressBar:[70,150]}
1665:   },
1666:   [BASE.PBAT]:{
1667:     extrusion:{zone1:[110,125],zone2:[120,135],zone3:[130,145],zone4:[135,150],die:[135,150],screwRPM:[40,90],meltPressBar:[50,120],coolingRoll:[15,25],lineSpeed:[5,30]},
1668:     sheet:{zone1:[110,125],zone2:[120,135],zone3:[130,145],zone4:[135,150],zone5:[135,150],die:[135,150],chillTop:[15,25],chillMid:[15,25],chillBot:[15,25],rollRPM:[10,35],lineSpeed:[5,30],targetThickness:[200,2000],meltPressBar:[50,120]},
1669:     injection:{barrel1:[120,130],barrel2:[130,140],barrel3:[135,145],nozzle:[140,150],mold:[20,35],injSpeed:[30,120],injPressMPa:[50,100],packPressMPa:[25,60],packTime:[5,18],coolTime:[8,30],backPressBar:[20,60],screwRPM:[30,90],hold1P:[25,60],hold1T:[2,10],hold2P:[15,45],hold2T:[2,10]},
1670:     blownfilm:{zone1:[115,125],zone2:[125,135],zone3:[135,145],zone4:[140,150],die:[140,150],bur:[1.8,3.0],flh:[200,600],takeup:[10,60],dieGap:[0.8,1.5],meltPressBar:[70,150],airTemp:[15,25]},
1671:     blowmolding:{zone1:[120,130],zone2:[130,140],zone3:[135,145],head:[140,150],die:[140,150],accHead:[140,150],blowPressBar:[5,10],preBlowBar:[2,5],mold:[20,30],coolTime:[20,60]},
1672:     castfilm:{zone1:[120,130],zone2:[130,140],zone3:[135,145],die:[140,150],chillTop:[10,18],lineSpeed:[10,40],targetThickness:[20,200],meltPressBar:[50,120]}
1673:   },
1674:   [BASE.PBS]:{
1675:     extrusion:{zone1:[140,150],zone2:[150,160],zone3:[155,165],zone4:[160,170],die:[160,170],screwRPM:[40,80],meltPressBar:[60,130],coolingRoll:[15,25],lineSpeed:[5,30]},
1676:     sheet:{zone1:[140,150],zone2:[150,160],zone3:[155,165],zone4:[160,170],zone5:[160,170],die:[165,170],chillTop:[15,25],chillMid:[15,25],chillBot:[15,25],rollRPM:[10,35],lineSpeed:[5,30],targetThickness:[200,2000],meltPressBar:[60,130]},
1677:     injection:{barrel1:[150,160],barrel2:[155,165],barrel3:[160,170],nozzle:[165,170],mold:[20,35],injSpeed:[30,120],injPressMPa:[60,110],packPressMPa:[30,70],packTime:[5,18],coolTime:[8,35],backPressBar:[20,60],screwRPM:[30,90],hold1P:[35,70],hold1T:[2,10],hold2P:[25,60],hold2T:[2,10]},
1678:     blownfilm:{zone1:[145,155],zone2:[150,160],zone3:[155,165],zone4:[160,170],die:[165,170],bur:[1.8,3.0],flh:[200,600],takeup:[10,60],dieGap:[0.8,1.5],meltPressBar:[70,150],airTemp:[15,25]},
1679:     blowmolding:{zone1:[150,160],zone2:[155,165],zone3:[160,170],head:[165,170],die:[165,170],accHead:[165,170],blowPressBar:[6,12],preBlowBar:[2,6],mold:[20,30],coolTime:[20,70]},
1680:     castfilm:{zone1:[150,160],zone2:[155,165],zone3:[160,170],die:[165,170],chillTop:[10,18],lineSpeed:[10,40],targetThickness:[20,200],meltPressBar:[60,130]}
1681:   },
1682:   [BASE.PBSA]:{
1683:     extrusion:{zone1:[125,135],zone2:[135,145],zone3:[140,150],zone4:[145,155],die:[150,160],screwRPM:[40,80],meltPressBar:[50,120],coolingRoll:[15,25],lineSpeed:[5,30]},
1684:     sheet:{zone1:[125,135],zone2:[135,145],zone3:[140,150],zone4:[145,155],zone5:[145,160],die:[150,160],chillTop:[15,25],chillMid:[15,25],chillBot:[15,25],rollRPM:[10,35],lineSpeed:[5,30],targetThickness:[200,2000],meltPressBar:[50,120]},
1685:     injection:{barrel1:[135,145],barrel2:[140,150],barrel3:[145,155],nozzle:[150,160],mold:[20,35],injSpeed:[30,120],injPressMPa:[50,90],packPressMPa:[25,60],packTime:[5,18],coolTime:[8,30],backPressBar:[20,60],screwRPM:[30,90],hold1P:[25,55],hold1T:[2,10],hold2P:[15,45],hold2T:[2,10]},
1686:     blownfilm:{zone1:[130,140],zone2:[140,150],zone3:[145,155],zone4:[150,160],die:[150,160],bur:[1.8,3.0],flh:[200,600],takeup:[10,60],dieGap:[0.8,1.5],meltPressBar:[60,140],airTemp:[15,25]},
1687:     blowmolding:{zone1:[135,145],zone2:[140,150],zone3:[145,155],head:[150,160],die:[150,160],accHead:[150,160],blowPressBar:[5,10],preBlowBar:[2,5],mold:[20,30],coolTime:[20,60]},
1688:     castfilm:{zone1:[135,145],zone2:[140,150],zone3:[145,155],die:[150,160],chillTop:[10,18],lineSpeed:[10,40],targetThickness:[20,200],meltPressBar:[50,120]}
1689:   },
1690:   [BASE.PHA_PLA]:{},[BASE.PHA_PBS]:{},[BASE.PHA_PBAT]:{}
1691: };
1692: 
1693: /* ========= Schemas ========= */
1694: function f(id,ko,en,unit){if(unit===undefined){unit=en;en=PHAEvidence.FIELD_EN[id]||ko;}return {id,ko,en,unit};}
1695: const SCHEMAS={
1696:   extrusion:[f('zone1','Zone 1 온도','Zone 1 Temp','°C'),f('zone2','Zone 2 온도','°C'),
1697:              f('zone3','Zone 3 온도','°C'),f('zone4','Zone 4 온도','°C'),f('die','다이 온도','°C'),
1698:              f('screwRPM','스크류 속도','RPM'),f('meltPressBar','용융 압력','bar'),
1699:              f('coolingRoll','쿨링롤 온도','°C'),f('lineSpeed','라인 속도','m/min')],
1700:   sheet:[f('zone1','Zone 1 온도','°C'),f('zone2','Zone 2 온도','°C'),f('zone3','Zone 3 온도','°C'),
1701:          f('zone4','Zone 4 온도','°C'),f('zone5','Zone 5 온도','°C'),f('die','다이 온도','°C'),
1702:          f('chillTop','칠롤 상단','°C'),f('chillMid','칠롤 중단','°C'),f('chillBot','칠롤 하단','°C'),
1703:          f('rollRPM','롤 회전수','RPM'),f('lineSpeed','라인 속도','m/min'),f('targetThickness','목표 두께','µm'),f('meltPressBar','용융 압력','bar')],
1704:   injection:[f('barrel1','배럴 1','°C'),f('barrel2','배럴 2','°C'),f('barrel3','배럴 3','°C'),f('nozzle','노즐','°C'),
1705:              f('mold','금형 온도','°C'),f('injSpeed','사출 속도','mm/s'),f('injPressMPa','사출 압력','MPa'),f('packPressMPa','보압','MPa'),
1706:              f('packTime','보압 시간','s'),f('coolTime','냉각 시간','s'),f('backPressBar','백프레셔','bar'),f('screwRPM','스크류 회전수','RPM'),
1707:              f('hold1P','보압1 압력','MPa'),f('hold1T','보압1 시간','s'),f('hold2P','보압2 압력','MPa'),f('hold2T','보압2 시간','s')],
1708:   blownfilm:[f('zone1','Zone 1 온도','°C'),f('zone2','Zone 2 온도','°C'),f('zone3','Zone 3 온도','°C'),f('zone4','Zone 4 온도','°C'),
1709:              f('die','다이 온도','°C'),f('bur','BUR','–'),f('flh','FLH','mm'),f('takeup','테이크업 속도','m/min'),
1710:              f('dieGap','다이 갭','mm'),f('meltPressBar','용융 압력','bar'),f('airTemp','냉각 공기 온도','°C')],
1711:   blowmolding:[f('zone1','Zone 1 온도','°C'),f('zone2','Zone 2 온도','°C'),f('zone3','Zone 3 온도','°C'),
1712:                f('head','헤드 온도','°C'),f('die','다이 온도','°C'),f('accHead','어큐뮬레이터 헤드','°C'),
1713:                f('blowPressBar','블로우 압력','bar'),f('preBlowBar','프리블로우 압력','bar'),f('mold','금형 온도','°C'),f('coolTime','냉각 시간','s')],
1714:   castfilm:[f('zone1','Zone 1 온도','°C'),f('zone2','Zone 2 온도','°C'),f('zone3','Zone 3 온도','°C'),
1715:             f('die','다이 온도','°C'),f('chillTop','칠롤 온도','°C'),f('lineSpeed','라인 속도','m/min'),f('targetThickness','목표 두께','µm'),f('meltPressBar','용융 압력','bar')]
1716: };
1717: 
1718: /* ========= Troubleshooting content ========= */
1719: const TS={
1720:   ko:[{title:"🔴 표면 결함",items:[["샤크스킨","다이 온도 +5~10°C, 압력 낮춤, 가공조제 검토"],["멜트 프랙처","전단속도 낮춤, 온도 프로파일 최적화, 다이 갭 조정"],["다이 라인","다이 청소/온도 균일화, 압력 안정화"]]},
1721:       {title:"🟡 기계적 물성 저하",items:[["인장강도 부족","분자량 저하 확인, 가공온도↓, 체류시간↓"],["신율 감소","가소제/블렌드 비율 조정, 냉각 속도 최적화"],["충격 저하","상용화제, 어닐링"]]},
1722:       {title:"🔵 가공성 문제",items:[["토출 불안정","스크류 속도 안정화, 건조/공급 확인, 온도 균일화"],["압력 변동","스크류/필터 점검, 건조/수분관리"],["색상 불균일","MB 분산 개선, 혼합 시간 증가, 온도 재조정"]]},
1723:       {title:"🟢 열적 특성 이슈",items:[["열변형 낮음","결정화도↑, 핵제, 어닐링 최적화"],["용융 거동 이상","DSC, 블렌드 균일성 확인, 이력 검토"],["열안정성 부족","AO 패키지 보강, 온도/체류 최소화"]]}],
1724:   en:[{title:"🔴 Surface Defects",items:[["Sharkskin","Raise die temp +5–10°C, reduce pressure, processing aid"],["Melt Fracture","Lower shear rate, optimize temp profile, adjust die gap"],["Die Lines","Clean die / improve temperature uniformity / stabilize pressure"]]},
1725:       {title:"🟡 Mechanical",items:[["Low Tensile","Check MW degradation; lower temp; shorten residence"],["Low Elongation","Tune plasticizer/blend; optimize cooling"],["Low Impact","Compatibilizer; anneal"]]},
1726:       {title:"🔵 Processability",items:[["Output Instability","Stabilize screw speed; dry feed; improve uniformity"],["Pressure Variation","Inspect screw/filter; drying & moisture control"],["Color Inconsistency","Improve MB dispersion; longer mixing; retune"]]},
1727:       {title:"🟢 Thermal",items:[["Low HDT","Increase crystallinity; nucleating agent; anneal"],["Abnormal Melting","DSC; blend uniformity; history review"],["Poor Thermal Stability","Reinforce AO; minimize temp/residence"]]}
1728: ]};
1729: 
1730: /* ========= Materials DB (editable, import/export) ========= */
1731: const MAT_DEFAULT={
1732:   "S1000P":{"density_g_cm3":1.24,"MFR_g_10min_190_2_16":null,"Tg_C":null,"Tm_C":170,"Tc_C":null,"tensile_MPa":null,"elongation_%":null,"izod_kJ_m2":null,"HDT_C":null},
1733:   "A1000P":{"density_g_cm3":1.23,"MFR_g_10min_190_2_16":null,"Tg_C":-15,"Tm_C":null,"Tc_C":null,"tensile_MPa":null,"elongation_%":null,"izod_kJ_m2":null,"HDT_C":null},
1734:   "CB0400A":{},"CB0104A":{},
1735:   "CA1180P":{"density_g_cm3":1.26,"MFR_g_10min_190_2_16":7,"Tg_C":-15,"Tm_C":162,"tensile_MPa":52,"elongation_%":23,"izod_kJ_m2":63,"HDT_C":51},"CA1170A":{},"CA1165A":{},"CA1670P":{},"CA1680":{},"CA1270P":{}
1736: };
1737: const MAT_KEY_ORDER=[
1738:   ["density_g_cm3","밀도 · Density","g/cm³"],
1739:   ["MFR_g_10min_190_2_16","용융지수 (MFR, 190 °C · 2.16 kg) · Local record","g/10min"],
1740:   ["Tg_C","유리전이 (Tg) · Glass transition temp","°C"],
1741:   ["Tm_C","융점 (Tm) · Melt temperature","°C"],
1742:   ["Tc_C","결정화 온도 (Tc) · Crystallization temp","°C"],
1743:   ["tensile_MPa","인장강도 · Tensile strength","MPa"],
1744:   ["elongation_%","파단신율 (ε_b) · Elongation at break","%"],
1745:   ["izod_kJ_m2","아이조드 충격강도 · Izod impact","kJ/m²"],
1746:   ["HDT_C","열변형 온도 (HDT, 0.455 MPa) · Heat deflection temp","°C"]
1747: ];
1748: 
1749: /* ========= Utilities ========= */
1750: function $(id){return document.getElementById(id)}; function allSel(s){return Array.from(document.querySelectorAll(s))};
1751: function i18nLookup(key, lang = LANG){
1752:   let value = I18N[lang];
1753:   for (const part of String(key).split('.')) value = value?.[part];
1754:   return value;
1755: }
1756: function _t(key){return i18nLookup(key) ?? key}
1757: /* Display-only number formatter: trims IEEE-754 float tails (e.g. 24.200000000000003 → 24.2)
1758:    while preserving integers as whole numbers. Returns non-numeric inputs unchanged so
1759:    placeholder/fallback strings like "-" still render. */
1760: function fmtR(n){
1761:   if(n===null||n===undefined) return '';
        ```
