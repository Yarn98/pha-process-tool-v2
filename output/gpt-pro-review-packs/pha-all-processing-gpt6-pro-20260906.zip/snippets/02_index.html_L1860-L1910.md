        # Snippet

        - Path: `index.html`
        - Lines: `1860-1910`
        - Reason: Actual recipe assembly and rendering

        ```html
        1860:   const msel=$('mat_grade'); msel.innerHTML=''; GRADES.forEach(g=>{const o=document.createElement('option');o.value=g.value;o.textContent=g.value;msel.appendChild(o)});}
1861: function profileOf(grade){const g=GRADES.find(x=>x.value===grade); return g?g.profile:null}
1862: function mixReco(a,b,alpha){const out={}; for(const k of Object.keys(a)){if(!b[k]){out[k]=a[k];continue} out[k]=[ Math.round(a[k][0]*(1-alpha)+b[k][0]*alpha), Math.round(a[k][1]*(1-alpha)+b[k][1]*alpha) ];} return out}
1863: function getReco(profile,proc){
1864:   let ov={}; try{ov=JSON.parse(localStorage.getItem('reco_overrides')||'{}');}catch(_){}
1865:   let base;
1866:   if(RECO[profile] && RECO[profile][proc]) base=RECO[profile][proc];
1867:   else if(profile===BASE.PHA_PLA) base=mixReco(RECO[BASE.PHA_AMOR][proc],RECO[BASE.PLA][proc],.5);
1868:   else if(profile===BASE.PHA_PBS) base=mixReco(RECO[BASE.PHA_SEMI][proc],RECO[BASE.PBS][proc],.5);
1869:   else if(profile===BASE.PHA_PBAT) base=mixReco(RECO[BASE.PHA_AMOR][proc],RECO[BASE.PBAT][proc],.5);
1870:   else base=profile?RECO[BASE.PHA_SEMI][proc]:{};
1871:   const grade=$('grade').value;
1872:   const reference=PHAEvidence.reference(grade,proc,$('moldMode')?.value);
1873:   // Legacy profile keys may contain an auto-applied additive trial. Preserve, but do not silently reuse.
1874:   const key=PHAEvidence.overrideKey(grade,proc,$('moldMode')?.value);
1875:   return {...base,...reference.ranges,...(ov[key]||{})};
1876: }
1877: 
1878: /* ========= Dynamic form ========= */
1879: function rebuildForm(keepValues=false){
1880:   const entered=keepValues===true?Object.fromEntries(allSel('#dynamicFields input').map(input=>[input.id,input.value])):{};
1881:   const proc=$('process').value, grade=$('grade').value, profile=profileOf(grade), schema=SCHEMAS[proc], rec=getReco(profile,proc);
1882:   const wrap=$('dynamicFields'); wrap.innerHTML='';
1883:   for(const fld of schema){
1884:     const id='f_'+fld.id, label = (LANG==='en'?fld.en:fld.ko) + (fld.unit?` (${fld.unit})`:''); const div=document.createElement('div'); div.className='group';
1885:     const rangeText=rec[fld.id]?`${LANG==='ko'?'참고':'Reference'}: ${fmtR(rec[fld.id][0])}–${fmtR(rec[fld.id][1])}${fld.unit?' '+fld.unit:''}`:'';
1886:     const source=typeof phaReferenceTag==='function'?phaReferenceTag(fld.id,grade,proc):'';
1887:     div.innerHTML=`<label for="${id}">${label}</label><input id="${id}" type="number" step="any" inputmode="decimal" placeholder="${rec[fld.id]?fmtR(rec[fld.id][0])+'-'+fmtR(rec[fld.id][1]):''}">${rangeText?'<span class="range-hint">'+rangeText+'</span>':''}<span class="field-source">${source}</span>`;
1888:     wrap.appendChild(div);
1889:   }
1890:   Object.entries(entered).forEach(([id,value])=>{if($(id))$(id).value=value;});
1891:   refreshParamTable();
1892:   if(typeof updateGuideLinks==='function') updateGuideLinks();
1893:   if(typeof renderProcessAtlas==='function') renderProcessAtlas();
1894: }
1895: 
1896: /* ========= Table/status ========= */
1897: function statusOf(v,r){return PHAEvidence.status(v,r);}
1898: function refreshParamTable(){
1899:   const proc=$('process').value, grade=$('grade').value, profile=profileOf(grade), schema=SCHEMAS[proc], rec=getReco(profile,proc);
1900:   const tb=$('paramTable'); tb.innerHTML='';
1901:   schema.forEach(f=>{const val=$('f_'+f.id)?.value||''; const range=rec[f.id]||['-','-']; const s=statusOf(val,range);
1902:     const cls=s==='ok'?'ok':(s==='crit'?'crit':(s==='empty'?'empty':'warn'));
1903:     const sText=(LANG==='ko'?(s==='ok'?'범위 안':s==='empty'?'미입력':s==='unknown'?'근거 미확인':'범위 밖'):(s==='ok'?'Within reference':s==='empty'?'Not entered':s==='unknown'?'Unverified':'Outside reference'));
1904:     const tr=document.createElement('tr'); tr.innerHTML=`<td>${LANG==='en'?f.en:f.ko}${f.unit?' ('+f.unit+')':''}</td><td>${val||'-'}</td><td>${fmtR(range[0])}-${fmtR(range[1])}</td><td><span class="badge ${cls}">${sText}</span></td>`; tb.appendChild(tr);
1905:   });
1906: }
1907: 
1908: /* ========= Save/History/Import/Export ========= */
1909: function collectEntry(){const proc=$('process').value, grade=$('grade').value, schema=SCHEMAS[proc]; const data={ts:new Date().toISOString(),proc,grade,params:{},notes:$('notes').value};
1910:   schema.forEach(f=> data.params[f.id]=$('f_'+f.id)?.value||''); return data;}
        ```
