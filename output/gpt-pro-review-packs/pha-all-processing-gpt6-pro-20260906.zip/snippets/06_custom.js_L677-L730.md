        # Snippet

        - Path: `custom.js`
        - Lines: `677-730`
        - Reason: Online KB normalization and fallback loading

        ```js
        677: function normalizeTroubleshootingItem(item) {
678:   if (!item || typeof item !== 'object') return null;
679:   return {
680:     ...item,
681:     likely_causes: Array.isArray(item.likely_causes) ? item.likely_causes : [],
682:     likely_causes_ko: Array.isArray(item.likely_causes_ko) ? item.likely_causes_ko : item.likely_causes_ko,
683:     quick_fixes: Array.isArray(item.quick_fixes) ? item.quick_fixes : [],
684:     quick_fixes_ko: Array.isArray(item.quick_fixes_ko) ? item.quick_fixes_ko : item.quick_fixes_ko,
685:     root_fixes: Array.isArray(item.root_fixes) ? item.root_fixes : [],
686:     root_fixes_ko: Array.isArray(item.root_fixes_ko) ? item.root_fixes_ko : item.root_fixes_ko,
687:     control_knobs: Array.isArray(item.control_knobs) ? item.control_knobs : [],
688:     control_knobs_ko: Array.isArray(item.control_knobs_ko) ? item.control_knobs_ko : item.control_knobs_ko,
689:     related_images: Array.isArray(item.related_images) ? item.related_images : [],
690:   };
691: }
692: 
693: // Fetch the requested field by language, with JSON-first lookup and TS_KO fallback.
694: function tsFieldByLang(item, field, lang) {
695:   if (!item) return null;
696:   if (field === 'plain') {
697:     if (lang === 'ko') return item.plain_ko ?? TS_KO[item.symptom]?.plain ?? null;
698:     return item.plain_en ?? null;
699:   }
700:   if (lang === 'ko') {
701:     const localized = item[`${field}_ko`];
702:     if (localized != null) return localized;
703:     const t = TS_KO[item.symptom];
704:     if (t && t[field] != null) return t[field];
705:   }
706:   return item[field];
707: }
708: 
709: // Process label translation helper.
710: function tsProcLabel(proc, lang) {
711:   if (lang === 'ko' && PROC_KO[proc]) return PROC_KO[proc];
712:   return (proc || 'general').charAt(0).toUpperCase() + (proc || 'general').slice(1);
713: }
714: 
715: // Load troubleshooting knowledge base from embedded dataset
716: async function loadTroubleshootingKB() {
717:   const fallback = Array.isArray(TS_DATA)
718:     ? TS_DATA.map(normalizeTroubleshootingItem).filter(Boolean)
719:     : [];
720:   try {
721:     const res = await fetch('data/troubleshooting_kb.json', { cache: 'no-store' });
722:     if (!res.ok) throw new Error(`HTTP ${res.status}`);
723:     const data = await res.json();
724:     if (!Array.isArray(data)) throw new Error('Troubleshooting KB payload must be an array');
725:     window.tsData = data.map(normalizeTroubleshootingItem).filter(Boolean);
726:   } catch (e) {
727:     console.warn('Failed to load troubleshooting KB, falling back to embedded data.', e);
728:     window.tsData = fallback;
729:   }
730:   if (typeof renderTS === 'function') renderTS();
        ```
